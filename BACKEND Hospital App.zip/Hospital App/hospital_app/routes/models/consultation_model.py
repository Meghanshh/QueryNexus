from hospital_app import db

class Consultation